export const USER_SEARCH_INPUT = 'User-Input';
export const USER_SELECTED = 'User-Selected';
export const BACK_TO_USER_SEARCH = 'Back-To-User-Search';