//import {USER_SEARCH_INPUT, USER_SELECTED, BACK_TO_USER_SEARCH} from './types';
/*export handleInputChange = () => ({type: USER_SEARCH_INPUT})
export handleUserSelect = () => ({type: USER_SELECTED})
export handleJumpBack = () => ({type: BACK_TO_USER_SEARCH})*/